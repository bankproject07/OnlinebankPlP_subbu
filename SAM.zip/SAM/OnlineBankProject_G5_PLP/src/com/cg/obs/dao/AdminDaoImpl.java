package com.cg.obs.dao;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TemporalType;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Transactions;
import com.cg.obs.exception.UserException;

@Repository("adminDao")
public class AdminDaoImpl implements IAdminDao
{
	@PersistenceContext
	private EntityManager manager;
	
	
	public AdminDaoImpl()
	{
		
	}

	public AdminDaoImpl(EntityManager manager)
	{
	
		this.manager = manager;
	}

	public EntityManager getManager()
	{
		return manager;
	}

	public void setManager(EntityManager manager)
	{
		this.manager = manager;
	}

	@Override
	public Customer getCustomerbyId(int id) throws UserException
	{
		Customer customer=null ;
		try
		{
			customer = new Customer();
			customer  = manager.find(Customer.class,id);
			System.out.println("custId :"+customer);
		} 
		catch (Exception e)
		{
			throw new UserException("Customer ID not Found  " +e.getMessage());
		}
		if(customer == null)
		{
			throw new UserException("Customer Doesn't Exist With Id " +id);
		}
		return customer;
	}

	@Override
	public List<Transactions> viewDailyReport(Date StartDate)throws UserException
			{
		List<Transactions> transaction=null;
		try
		{
			String str="select t from Transactions t where t.dateOfTransaction=:StartDate";
			TypedQuery<Transactions>query=manager.createQuery(str,Transactions.class);
			query.setParameter("StartDate",StartDate);
			transaction=query.getResultList();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return transaction;
		
		}

	@Override
	public List<Transactions> viewMonthlyReport(Date StartDate, Date EndDate)
			throws UserException 
			{
		
		
		List<Transactions> tlist;
		try {
			String str="select tfrom Transactions t where t.dateOfTransaction betwwen :StartDate and :EndDate";
			TypedQuery<Transactions>query=manager.createQuery(str,Transactions.class);
			query.setParameter("StartDate",StartDate);
			query.setParameter("EndDate",EndDate);
			tlist = query.getResultList();
		} 
		catch (UserException e) 
		{
		
			throw new UserException("no data found:"+e.getMessage());
		}
		return tlist;
	}

	@Override
	public List<Transactions> viewYearlyReport(Date StartDate, Date EndDate)
			throws UserException
	{
		List<Transactions> tlist;
		try {
			String str="select tfrom Transactions t where t.dateOfTransaction betwwen :StartDate and :EndDate";
			TypedQuery<Transactions>query=manager.createQuery(str,Transactions.class);
			query.setParameter("StartDate",StartDate);
			query.setParameter("EndDate",EndDate);
			tlist = query.getResultList();
		} 
		catch (UserException e) 
		{
		
			throw new UserException("no data found:"+e.getMessage());
		}
		return tlist;
	}

	

	

}
