create sequence seq_fundtransfer_id start with 1000 increment by 1;

create sequence accId_seq start with 12001200 increment by 1;

create sequence custId_seq start with 1500200 increment by 1;

create sequence seq_service_num  start with 12000 increment by 1;

create sequence seq_transactionid  start with 130010 increment by 1;

drop sequence accId_seq;

select accId_seq.nextVal from dual;

select * from USER_TABLE;

insert into USER_TABLE values(123456,12001215,123,'hg','hgf',789,'U');

insert into account_master values(accid_seq.nextVal,1500249,'Saving',1500,'01-apr-2017');

select * from customer1;

select * from REQUESTTABLE;

delete from REQUESTTABLE;

select *  from ACCOUNT_MASTER;