package com.cg.obs.controller;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.Users;
import com.cg.obs.exception.UserException;
import com.cg.obs.service.IUserService;



@Controller
public class BankingApplicationController {

	
	@Autowired
	IUserService userService;
	
	public BankingApplicationController() {
		// TODO Auto-generated constructor stub
	}

	public IUserService getUserService() {
		return userService;
	}

	public void setUserService(IUserService userService) {
		this.userService = userService;
	}

	public BankingApplicationController(IUserService userService) {
		super();
		this.userService = userService;
	}
	
	//=================================================
	//		USER LOGIN
	//==================================================
	@RequestMapping("Login")
	public String getLoginPage(@RequestParam("username") int userId,@RequestParam("password") String password,Model model)
	{
		
		System.out.println("123 "+userId+" "+password);
		Users user=userService.getUser(userId);
		System.out.println("user "+user);
		if(user!=null)
		{
			
			
			if(password.equalsIgnoreCase(user.getLoginPassword()))
			{
				System.out.println("user login success");
				return "index";
			}
		
		
		}
		model.addAttribute("errMsg", "Login error");
			return "pages/ErrorPage";
		
	}
	
	//================================================
	//			ADMIN LOGIN
	//================================================
	
	@RequestMapping("Adminlogin")
	public String getAdminPage(@RequestParam("username") String username,@RequestParam("password") String pass,Model model)
	{
		if(username.equalsIgnoreCase("admin") && pass.equalsIgnoreCase("admin") )
		 {
			 return "adminIndex";
		 }
		 
			 model.addAttribute("errMsg", "Invalid UserName And Password");
			 return "adminIndex";
	}
	//=============================================
	//			GET NEW ACCOUNT PAGE
	//=============================================
	@RequestMapping("NewAccount")
	public String getNewAccountPage(Model model)
	{
		/*System.out.println("get new page");
		List<String> accountType = new ArrayList<String>();
		accountType.add("Select");
		accountType.add("Saving Account");
		accountType.add("Current Account");
		
		model.addAttribute("Type",accountType);
		model.addAttribute("request",new RequestTable());*/
		return "pages/NewAccount";
	}
	
	
	
	
	//===================================================
	//			ACCOUNT REQUEST
	//==================================================
	@RequestMapping(value="processRegistration",method = RequestMethod.POST)
	public String addAccountRequest(@RequestParam("txtCustId") int customerid , RequestTable reqTab,Model model)
	{
		System.out.println("processRegistration"+customerid);
		
		/*List<String> accountType = new ArrayList<String>();
		accountType.add("Select");
		accountType.add("Saving Account");
		accountType.add("Current Account");
		
		model.addAttribute("Type",accountType);
		model.addAttribute("request", reqTab);*/
		System.out.println("123");
		Customer customer = userService.getCustomerbyId(customerid);
		System.out.println(customer);
		int accId = -1;
		if(customer!=null)
		{
			System.out.println(" if exist "+customer);
			try
			{
				accId = userService.addRequest(reqTab);
				System.out.println(accId);
				model.addAttribute("AccountID", accId);
				return "pages/SuccessReg";
			} 
			catch (UserException e)
			{
				model.addAttribute("errMsg","Unable To add New Account Creation Request "+e.getMessage());
				return "pages/NewAccount";
			}
		}
		else
		{
			System.out.println("if not");
			model.addAttribute("errMsg","Customer Id Doesn't Exist");
			return "pages/NewAccount";
		}
	}
}











