package com.cg.obs.dao;

import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.exception.UserException;

public interface IAdminDao 
{
	public Customer getCustomerbyId(int id) throws UserException;
}
