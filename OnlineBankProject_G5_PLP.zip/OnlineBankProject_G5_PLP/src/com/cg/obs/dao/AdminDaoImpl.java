package com.cg.obs.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.Customer;

import com.cg.obs.exception.UserException;

@Repository("adminDao")
public class AdminDaoImpl implements IAdminDao
{
	@PersistenceContext
	private EntityManager manager;
	
	
	public AdminDaoImpl()
	{
		
	}

	public AdminDaoImpl(EntityManager manager)
	{
	
		this.manager = manager;
	}

	public EntityManager getManager()
	{
		return manager;
	}

	public void setManager(EntityManager manager)
	{
		this.manager = manager;
	}

	@Override
	public Customer getCustomerbyId(int id) throws UserException
	{
		Customer customer=null ;
		try
		{
			customer = new Customer();
			customer  = manager.find(Customer.class,id);
			System.out.println("custId :"+customer);
		} 
		catch (Exception e)
		{
			throw new UserException("Customer ID not Found  " +e.getMessage());
		}
		if(customer == null)
		{
			throw new UserException("Customer Doesn't Exist With Id " +id);
		}
		return customer;
	}

	

	

}
