package com.cg.obs.bean;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Admin {
	@Id
	private String adminid;
	private String adminPassword;

	public Admin() {
		super();
	}

	public Admin(String adminid, String adminPassword) {
		super();
		this.adminid = adminid;
		this.adminPassword = adminPassword;
	}

	public String getAdminid() {
		return adminid;
	}

	public void setAdminid(String adminid) {
		this.adminid = adminid;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	@Override
	public String toString() {
		return "Admin [adminid=" + adminid + ", adminPassword=" + adminPassword
				+ "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adminid == null) ? 0 : adminid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Admin other = (Admin) obj;
		if (adminid == null) {
			if (other.adminid != null)
				return false;
		} else if (!adminid.equals(other.adminid))
			return false;
		return true;
	}

}
